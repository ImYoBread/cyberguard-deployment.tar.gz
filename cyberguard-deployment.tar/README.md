# CyberGuard DDoS Monitoring Dashboard

A professional-grade, real-time DDoS attack monitoring and visualization dashboard built with Flask and modern web technologies.

## 🚀 Features

### Real-time Monitoring
- **Live Attack Visualization**: Interactive world map showing DDoS attacks with animated packet flows
- **Real-time Metrics**: Bandwidth usage, packet counts, and server health monitoring
- **Threat Intelligence**: Detailed attack vector analysis and geographic distribution

### Advanced Visualization
- **Interactive World Map**: Leaflet.js powered map with attack paths and arrows
- **Animated Packet Flows**: Real-time visualization of attack traffic
- **Dynamic Charts**: ECharts.js powered bandwidth and timeline visualizations
- **Professional UI**: Cyberpunk-inspired dark theme with smooth animations

### Data Integration
- **Mock Data Mode**: Built-in realistic attack simulation for demonstration
- **Real Data Support**: Ready for integration with:
  - NetFlow collectors
  - Syslog servers
  - REST API endpoints
  - Network monitoring tools

### Security Features
- **Flask Backend**: Secure Python web application
- **CORS Support**: Cross-origin resource sharing configured
- **Rate Limiting**: API endpoint protection
- **Production Ready**: systemd service, Nginx reverse proxy, SSL-ready

## 📊 Dashboard Views

### Main Dashboard
- Global attack visualization with world map
- Real-time attack statistics and metrics
- Critical alert notifications
- Response action controls

### Analytics Page
- Historical attack data and trends
- Geographic attack distribution
- Attack type analysis
- Performance metrics and charts

### Settings Page
- System configuration and monitoring preferences
- Alert threshold settings
- Real data source configuration
- System status monitoring

## 🛠️ Installation

### Quick Install (Recommended)

1. **Download and run the installation script:**
   ```bash
   wget https://example.com/install_cyberguard.sh
   chmod +x install_cyberguard.sh
   sudo ./install_cyberguard.sh
   ```

2. **Access the dashboard:**
   - Open your browser and navigate to: `http://your-server-ip`
   - The dashboard will be running on port 80 (HTTP)

### Manual Installation

1. **System Requirements:**
   - Ubuntu 22.04 LTS (recommended)
   - Python 3.8+
   - 2GB RAM minimum
   - 10GB disk space

2. **Install Dependencies:**
   ```bash
   sudo apt update && sudo apt upgrade -y
   sudo apt install -y python3 python3-pip python3-venv nginx supervisor
   ```

3. **Setup Application:**
   ```bash
   # Create application directory
   sudo mkdir -p /opt/cyberguard
   sudo chown $USER:$USER /opt/cyberguard
   
   # Copy application files
   cp -r cyberguard/* /opt/cyberguard/
   cd /opt/cyberguard
   
   # Create virtual environment
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

4. **Configure Nginx:**
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;
       
       location / {
           proxy_pass http://127.0.0.1:5000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       }
       
       location /static {
           alias /opt/cyberguard/static;
           expires 1y;
       }
   }
   ```

5. **Run the Application:**
   ```bash
   source venv/bin/activate
   python app.py
   ```

## ⚙️ Configuration

### Real Data Integration

To enable real data sources, modify the configuration in `config.py`:

```python
REAL_DATA_SOURCES = {
    'enable_real_data': True,  # Set to True for real data
    'sources': {
        'netflow': {
            'enabled': True,
            'collector_ip': '0.0.0.0',
            'port': 9995
        },
        'syslog': {
            'enabled': True,
            'port': 514
        },
        'api_polling': {
            'enabled': True,
            'endpoints': [
                'http://your-monitoring-api/api/stats'
            ],
            'interval': 30
        }
    }
}
```

### Security Configuration

1. **Change Default Secret Key:**
   ```python
   SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-very-secure-secret-key'
   ```

2. **Enable SSL (Production):**
   ```bash
   sudo apt install certbot python3-certbot-nginx
   sudo certbot --nginx -d your-domain.com
   ```

3. **Configure Firewall:**
   ```bash
   sudo ufw allow 80/tcp
   sudo ufw allow 443/tcp
   sudo ufw enable
   ```

## 🔧 Service Management

### Using systemd (Production)

```bash
# Start the service
sudo systemctl start cyberguard

# Stop the service
sudo systemctl stop cyberguard

# Restart the service
sudo systemctl restart cyberguard

# Check service status
sudo systemctl status cyberguard

# View logs
sudo journalctl -u cyberguard -f
```

### Manual Control (Development)

```bash
cd /opt/cyberguard
source venv/bin/activate
python app.py
```

## 📈 API Endpoints

### Get Attack Data
```http
GET /api/attack-data
Response: {
    "china": { "bandwidth": 2.3, "packets": 45000, ... },
    "russia": { "bandwidth": 1.8, "packets": 38000, ... },
    "server": { "cpu": 65, "status": "mitigating", ... }
}
```

### Get Historical Data
```http
GET /api/historical-data?type=bandwidth
Response: {
    "bandwidth": [
        {"timestamp": "2024-01-01T12:00:00", "china": 2.3, "russia": 1.8}
    ]
}
```

### Get Network Statistics
```http
GET /api/network-stats
Response: {
    "total_attacks_blocked": 1247,
    "peak_bandwidth": 4.1,
    "avg_response_time": 2.3,
    "system_uptime": 99.8
}
```

## 🛡️ Security Considerations

### Production Deployment

1. **SSL/TLS Encryption:**
   - Use Let's Encrypt for free SSL certificates
   - Configure HTTPS redirect
   - Update security headers

2. **Firewall Configuration:**
   - Only allow ports 80, 443, and SSH
   - Use fail2ban for intrusion prevention
   - Regular security updates

3. **Application Security:**
   - Change default secret keys
   - Use environment variables for sensitive data
   - Regular dependency updates

4. **Monitoring:**
   - Set up log monitoring
   - Configure alerting for critical events
   - Monitor system resources

### Data Protection

- All API endpoints support CORS protection
- Rate limiting on API calls
- Input validation and sanitization
- Secure session management

## 🔍 Troubleshooting

### Common Issues

1. **Application won't start:**
   ```bash
   # Check service status
   sudo systemctl status cyberguard
   
   # Check logs
   sudo journalctl -u cyberguard -f
   ```

2. **Nginx errors:**
   ```bash
   # Test Nginx configuration
   sudo nginx -t
   
   # Check Nginx logs
   sudo tail -f /var/log/nginx/error.log
   ```

3. **Permission errors:**
   ```bash
   # Fix ownership
   sudo chown -R cyberguard:cyberguard /opt/cyberguard
   ```

4. **Port conflicts:**
   ```bash
   # Check port usage
   sudo netstat -tlnp | grep :5000
   ```

### Performance Optimization

1. **Enable Gzip compression** (already configured in Nginx)
2. **Optimize database queries** (if using database)
3. **Use CDN for static assets**
4. **Enable browser caching**
5. **Monitor system resources**

## 📚 Architecture

### Frontend
- **HTML5/CSS3**: Responsive design with Tailwind CSS
- **JavaScript ES6+**: Modern JavaScript with async/await
- **Leaflet.js**: Interactive world map
- **ECharts.js**: Data visualization charts
- **Anime.js**: Smooth animations

### Backend
- **Flask**: Python web framework
- **Flask-CORS**: Cross-origin resource sharing
- **RESTful API**: JSON-based API endpoints
- **Threading**: Background data collection
- **Configuration Management**: Environment-based settings

### Data Flow
1. **Data Collection**: Mock data generator or real data sources
2. **API Endpoints**: Flask serves data via REST API
3. **Frontend**: JavaScript fetches and displays data
4. **Real-time Updates**: Periodic polling for live updates

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🔮 Future Enhancements

- **Database Integration**: PostgreSQL/MongoDB support
- **Machine Learning**: Anomaly detection for attacks
- **Mobile App**: React Native mobile client
- **Advanced Analytics**: ML-powered threat prediction
- **Integration Plugins**: Support for popular monitoring tools
- **API Webhooks**: Real-time notifications to external systems

## 📞 Support

For support and questions:
- Create an issue in the repository
- Check the troubleshooting section
- Review the API documentation

---

**CyberGuard DDoS Monitoring Dashboard** - Protecting networks worldwide with advanced visualization and real-time monitoring capabilities.