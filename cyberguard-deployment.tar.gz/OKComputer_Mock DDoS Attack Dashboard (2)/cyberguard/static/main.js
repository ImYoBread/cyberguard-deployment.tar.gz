// CyberGuard DDoS Monitoring Dashboard - Flask Integration
// Enhanced JavaScript with Real Data Support

// Global variables
let map;
let attackPaths = [];
let packetAnimations = [];
let timelineChart;
let bandwidthChart;
let attackData = {};
let historicalData = {};
let apiBaseUrl = '';

// Configuration
const CONFIG = {
    useRealData: false,  // Set to true to enable real data from Flask backend
    apiEndpoints: {
        attackData: '/api/attack-data',
        historicalData: '/api/historical-data',
        networkStats: '/api/network-stats',
        testConnection: '/api/test-connection'
    },
    updateInterval: 2000,  // 2 seconds
    chartUpdateInterval: 5000  // 5 seconds
};

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    initializeTime();
    initializeHeroText();
    checkBackendConnection();
});

// Check backend connection
async function checkBackendConnection() {
    try {
        const response = await fetch(CONFIG.apiEndpoints.testConnection);
        if (response.ok) {
            const data = await response.json();
            console.log('Backend connected:', data);
            
            // Update UI to show real data mode
            document.getElementById('data-source-indicator').textContent = 'REAL DATA MODE';
            document.getElementById('data-source-indicator').className = 'data-source-indicator real-data';
            CONFIG.useRealData = true;
            
            // Initialize dashboard with real data
            initializeDashboard();
        } else {
            throw new Error('Backend not available');
        }
    } catch (error) {
        console.log('Using mock data mode:', error.message);
        // Continue with mock data
        initializeDashboard();
    }
}

// Initialize dashboard components
async function initializeDashboard() {
    try {
        await loadInitialData();
        initializeMap();
        initializeCharts();
        startRealTimeUpdates();
        initializeInteractiveElements();
    } catch (error) {
        console.error('Error initializing dashboard:', error);
        // Fallback to mock data
        initializeMockDashboard();
    }
}

// Load initial data from backend
async function loadInitialData() {
    if (CONFIG.useRealData) {
        try {
            const [attackResponse, historicalResponse, statsResponse] = await Promise.all([
                fetch(CONFIG.apiEndpoints.attackData),
                fetch(CONFIG.apiEndpoints.historicalData),
                fetch(CONFIG.apiEndpoints.networkStats)
            ]);
            
            attackData = await attackResponse.json();
            historicalData = await historicalResponse.json();
            const networkStats = await statsResponse.json();
            
            // Update UI with real data
            updateDashboardWithRealData(attackData, networkStats);
        } catch (error) {
            console.error('Error loading real data:', error);
            useMockData();
        }
    } else {
        useMockData();
    }
}

// Initialize with mock data
function useMockData() {
    attackData = {
        china: {
            location: [39.9042, 116.4074],
            bandwidth: 2.3,
            packets: 45000,
            ip_range: '203.208.60.0/24',
            status: 'critical',
            duration: 18,
            country: 'China',
            city: 'Beijing',
            attack_vectors: { udp: 65, tcp: 25, http: 8, icmp: 2 }
        },
        russia: {
            location: [55.7558, 37.6176],
            bandwidth: 1.8,
            packets: 38000,
            ip_range: '95.213.128.0/24',
            status: 'critical',
            duration: 12,
            country: 'Russia',
            city: 'Moscow',
            attack_vectors: { udp: 55, tcp: 30, http: 12, icmp: 3 }
        },
        server: {
            location: [37.5407, -77.4360],
            ip: '10.0.0.1',
            cpu: 65,
            status: 'mitigating',
            response_time: 2.1,
            blocked_ips: 247,
            uptime: 99.8,
            name: 'OVH Virginia'
        }
    };
    
    updateDashboardWithMockData();
}

// Update dashboard with real data
function updateDashboardWithRealData(data, stats) {
    // Update critical alerts
    updateCriticalAlerts(data);
    
    // Update attack cards
    updateAttackCards(data);
    
    // Update packet analysis
    updatePacketAnalysis(data);
    
    // Update threat intelligence
    updateThreatIntelligence(data);
    
    // Update attack vectors
    updateAttackVectors(data);
    
    // Update network stats
    updateNetworkStats(stats);
}

// Update dashboard with mock data
function updateDashboardWithMockData() {
    updateDashboardWithRealData(attackData, {
        total_attacks_blocked: 1247,
        peak_bandwidth: 4.1,
        avg_response_time: 2.3,
        system_uptime: 99.8,
        active_threats: 2,
        mitigated_attacks: 89
    });
}

// Update critical alerts
function updateCriticalAlerts(data) {
    const alertsContainer = document.getElementById('critical-alerts');
    const alerts = [];
    
    if (data.china && data.china.status === 'critical') {
        alerts.push({
            country: 'China',
            city: data.china.city || 'Beijing',
            bandwidth: data.china.bandwidth,
            packets: data.china.packets
        });
    }
    
    if (data.russia && data.russia.status === 'critical') {
        alerts.push({
            country: 'Russia',
            city: data.russia.city || 'Moscow',
            bandwidth: data.russia.bandwidth,
            packets: data.russia.packets
        });
    }
    
    alertsContainer.innerHTML = alerts.map(alert => `
        <div class="attack-alert p-4 rounded-lg">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <span class="status-indicator status-danger"></span>
                    <div>
                        <h4 class="font-semibold text-red-400">CRITICAL: ${alert.country} DDoS Attack</h4>
                        <p class="text-sm text-gray-300">${alert.city} → Virginia (${alert.bandwidth} Gbps, ${alert.packets.toLocaleString()} packets/sec)</p>
                    </div>
                </div>
                <span class="text-xs text-red-400">ACTIVE</span>
            </div>
        </div>
    `).join('');
}

// Update attack cards
function updateAttackCards(data) {
    const cardsContainer = document.getElementById('attack-cards');
    const cards = [];
    
    if (data.china) {
        cards.push(createAttackCard('China', data.china));
    }
    
    if (data.russia) {
        cards.push(createAttackCard('Russia', data.russia));
    }
    
    if (data.server) {
        cards.push(createServerCard(data.server));
    }
    
    cardsContainer.innerHTML = cards.join('');
}

// Create attack card HTML
function createAttackCard(country, data) {
    const statusClass = data.status === 'critical' ? 'status-danger' : 'status-warning';
    const statusText = data.status === 'critical' ? 'CRITICAL' : 'WARNING';
    const statusColor = data.status === 'critical' ? 'red' : 'orange';
    
    return `
        <div class="cyber-card rounded-xl p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold">${country} Attack</h3>
                <div class="flex items-center space-x-2">
                    <span class="status-indicator ${statusClass}"></span>
                    <span class="text-xs bg-${statusColor}-600 px-2 py-1 rounded">${statusText}</span>
                </div>
            </div>
            <div class="metric-number" id="${country.toLowerCase()}-bandwidth">${data.bandwidth.toFixed(1)}</div>
            <p class="text-sm text-gray-400">Gbps Bandwidth</p>
            <div class="mt-4 space-y-2">
                <div class="flex justify-between text-sm">
                    <span>Source:</span>
                    <span class="jetbrains">${data.city || 'Unknown'}</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span>Target:</span>
                    <span class="jetbrains">Virginia</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span>Packets/sec:</span>
                    <span class="jetbrains text-green-400" id="${country.toLowerCase()}-packets">${data.packets.toLocaleString()}</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span>Duration:</span>
                    <span class="jetbrains">${data.duration || 0} min</span>
                </div>
            </div>
        </div>
    `;
}

// Create server card HTML
function createServerCard(data) {
    return `
        <div class="cyber-card rounded-xl p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold">${data.name || 'Target Server'}</h3>
                <div class="flex items-center space-x-2">
                    <span class="status-indicator status-warning"></span>
                    <span class="text-xs bg-orange-600 px-2 py-1 rounded">MITIGATING</span>
                </div>
            </div>
            <div class="metric-number" id="server-load">${data.cpu || 0}</div>
            <p class="text-sm text-gray-400">% CPU Usage</p>
            <div class="mt-4 space-y-2">
                <div class="flex justify-between text-sm">
                    <span>IP Address:</span>
                    <span class="jetbrains">${data.ip || 'Unknown'}</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span>Response Time:</span>
                    <span class="jetbrains text-green-400">${data.response_time || 0}ms</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span>Blocked IPs:</span>
                    <span class="jetbrains text-red-400">${data.blocked_ips || 0}</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span>Uptime:</span>
                    <span class="jetbrains">${data.uptime || 0}%</span>
                </div>
            </div>
        </div>
    `;
}

// Update packet analysis
function updatePacketAnalysis(data) {
    const analysisContainer = document.getElementById('packet-analysis');
    const totalBlocked = 1247832 + Math.floor(Math.random() * 1000);
    
    analysisContainer.innerHTML = `
        <div class="flex justify-between items-center">
            <span class="text-sm">China Packets/sec</span>
            <span class="jetbrains text-accent-green">${data.china ? data.china.packets.toLocaleString() : '0'}</span>
        </div>
        <div class="flex justify-between items-center">
            <span class="text-sm">Russia Packets/sec</span>
            <span class="jetbrains text-accent-green">${data.russia ? data.russia.packets.toLocaleString() : '0'}</span>
        </div>
        <div class="flex justify-between items-center">
            <span class="text-sm">Total Blocked</span>
            <span class="jetbrains text-accent-blue">${totalBlocked.toLocaleString()}</span>
        </div>
        <div class="flex justify-between items-center">
            <span class="text-sm">Attack Duration</span>
            <span class="jetbrains text-orange-400">${data.china ? (data.china.duration || 0) : 0}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}</span>
        </div>
    `;
}

// Update threat intelligence
function updateThreatIntelligence(data) {
    const intelligenceContainer = document.getElementById('threat-intelligence');
    
    const threats = [];
    if (data.china) {
        threats.push({
            country: 'China',
            ip_range: data.china.ip_range || '203.208.60.0/24',
            status: 'CRITICAL'
        });
    }
    
    if (data.russia) {
        threats.push({
            country: 'Russia',
            ip_range: data.russia.ip_range || '95.213.128.0/24',
            status: 'CRITICAL'
        });
    }
    
    intelligenceContainer.innerHTML = threats.map(threat => `
        <div class="flex justify-between items-center p-3 bg-gray-800 rounded-lg">
            <div>
                <p class="font-medium">Source IP Range</p>
                <p class="text-sm text-gray-400">${threat.ip_range} (${threat.country})</p>
            </div>
            <span class="text-xs bg-red-600 px-2 py-1 rounded">${threat.status}</span>
        </div>
    `).join('') + `
        <div class="flex justify-between items-center p-3 bg-gray-800 rounded-lg">
            <div>
                <p class="font-medium">Target Server</p>
                <p class="text-sm text-gray-400">${data.server ? data.server.ip : '10.0.0.1'} (OVH Virginia)</p>
            </div>
            <span class="text-xs bg-orange-600 px-2 py-1 rounded">MITIGATING</span>
        </div>
    `;
}

// Update attack vectors
function updateAttackVectors(data) {
    const vectorsContainer = document.getElementById('attack-vectors');
    const vectors = data.china ? data.china.attack_vectors : { udp: 65, tcp: 25, http: 8, icmp: 2 };
    
    const colors = {
        udp: 'red',
        tcp: 'orange',
        http: 'yellow',
        icmp: 'blue'
    };
    
    vectorsContainer.innerHTML = Object.entries(vectors).map(([vector, percentage]) => `
        <div class="p-3 bg-${colors[vector]}-900 bg-opacity-30 rounded-lg text-center">
            <div class="text-lg font-bold text-${colors[vector]}-400">${vector.toUpperCase()} FLOOD</div>
            <div class="text-xs text-gray-400">${percentage}% of traffic</div>
        </div>
    `).join('');
}

// Update network stats
function updateNetworkStats(stats) {
    // Update active threats counter
    document.getElementById('active-threats').textContent = stats.active_threats || 2;
}

// Initialize world map with arrows
function initializeMap() {
    // Initialize Leaflet map
    map = L.map('map', {
        center: [30, 0],
        zoom: 2,
        zoomControl: false,
        attributionControl: false
    });
    
    // Add dark tile layer
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd'
    }).addTo(map);
    
    // Add attack locations
    addAttackMarkers();
    
    // Create attack paths with arrows
    createAttackPathsWithArrows();
    
    // Start packet flow animation
    startPacketFlow();
}

// Add attack markers to map
function addAttackMarkers() {
    if (!attackData.china || !attackData.russia || !attackData.server) return;
    
    // China attack marker
    const chinaMarker = L.circleMarker(attackData.china.location, {
        radius: 15,
        color: '#ff4757',
        fillColor: '#ff4757',
        fillOpacity: 0.8,
        weight: 3
    }).addTo(map);
    
    chinaMarker.bindPopup(`
        <div class="text-gray-800 p-2">
            <h3 class="font-bold text-red-600 mb-2">🇨🇳 ${attackData.china.country || 'China'} Attack</h3>
            <div class="space-y-1 text-sm">
                <p><strong>Location:</strong> ${attackData.china.city || 'Beijing'}</p>
                <p><strong>Bandwidth:</strong> ${attackData.china.bandwidth} Gbps</p>
                <p><strong>Packets:</strong> ${attackData.china.packets.toLocaleString()}/sec</p>
                <p><strong>IP Range:</strong> ${attackData.china.ip_range}</p>
                <p><strong>Duration:</strong> ${attackData.china.duration} min</p>
                <div class="mt-2 pt-2 border-t">
                    <p class="text-xs"><strong>Attack Vectors:</strong></p>
                    <p class="text-xs">UDP Flood: ${attackData.china.attack_vectors ? attackData.china.attack_vectors.udp : 65}%</p>
                    <p class="text-xs">TCP SYN: ${attackData.china.attack_vectors ? attackData.china.attack_vectors.tcp : 25}%</p>
                </div>
            </div>
        </div>
    `);
    
    // Russia attack marker
    const russiaMarker = L.circleMarker(attackData.russia.location, {
        radius: 15,
        color: '#ff4757',
        fillColor: '#ff4757',
        fillOpacity: 0.8,
        weight: 3
    }).addTo(map);
    
    russiaMarker.bindPopup(`
        <div class="text-gray-800 p-2">
            <h3 class="font-bold text-red-600 mb-2">🇷🇺 ${attackData.russia.country || 'Russia'} Attack</h3>
            <div class="space-y-1 text-sm">
                <p><strong>Location:</strong> ${attackData.russia.city || 'Moscow'}</p>
                <p><strong>Bandwidth:</strong> ${attackData.russia.bandwidth} Gbps</p>
                <p><strong>Packets:</strong> ${attackData.russia.packets.toLocaleString()}/sec</p>
                <p><strong>IP Range:</strong> ${attackData.russia.ip_range}</p>
                <p><strong>Duration:</strong> ${attackData.russia.duration} min</p>
                <div class="mt-2 pt-2 border-t">
                    <p class="text-xs"><strong>Attack Vectors:</strong></p>
                    <p class="text-xs">UDP Flood: ${attackData.russia.attack_vectors ? attackData.russia.attack_vectors.udp : 55}%</p>
                    <p class="text-xs">TCP SYN: ${attackData.russia.attack_vectors ? attackData.russia.attack_vectors.tcp : 30}%</p>
                </div>
            </div>
        </div>
    `);
    
    // Server marker
    const serverMarker = L.circleMarker(attackData.server.location, {
        radius: 18,
        color: '#00d4ff',
        fillColor: '#00d4ff',
        fillOpacity: 0.8,
        weight: 3
    }).addTo(map);
    
    serverMarker.bindPopup(`
        <div class="text-gray-800 p-2">
            <h3 class="font-bold text-blue-600 mb-2">🖥️ ${attackData.server.name || 'OVH Virginia Server'}</h3>
            <div class="space-y-1 text-sm">
                <p><strong>IP:</strong> ${attackData.server.ip}</p>
                <p><strong>CPU Usage:</strong> ${attackData.server.cpu}%</p>
                <p><strong>Response Time:</strong> ${attackData.server.response_time}ms</p>
                <p><strong>Blocked IPs:</strong> ${attackData.server.blocked_ips}</p>
                <p><strong>Uptime:</strong> ${attackData.server.uptime}%</p>
                <p><strong>Status:</strong> <span class="text-orange-600">Mitigating Attack</span></p>
            </div>
        </div>
    `);
    
    // Add pulsing effect to markers
    addPulsingEffect(chinaMarker, '#ff4757');
    addPulsingEffect(russiaMarker, '#ff4757');
    addPulsingEffect(serverMarker, '#00d4ff');
}

// Create attack paths with arrows and labels
function createAttackPathsWithArrows() {
    if (!attackData.china || !attackData.russia || !attackData.server) return;
    
    // China to Virginia path with curved routing and arrow
    const chinaPath = L.polyline([
        attackData.china.location,
        [60, -30],
        [50, -60],
        [45, -70],
        attackData.server.location
    ], {
        color: '#ff4757',
        weight: 4,
        opacity: 0.9,
        dashArray: '15, 10'
    }).addTo(map);
    
    // Russia to Virginia path with curved routing and arrow
    const russiaPath = L.polyline([
        attackData.russia.location,
        [50, -20],
        [45, -50],
        [40, -65],
        attackData.server.location
    ], {
        color: '#ff4757',
        weight: 4,
        opacity: 0.9,
        dashArray: '15, 10'
    }).addTo(map);
    
    attackPaths.push(chinaPath, russiaPath);
    
    // Add arrow labels
    const chinaLabel = L.divIcon({
        className: 'arrow-label',
        html: `${attackData.china.bandwidth} Gbps`,
        iconSize: [80, 20],
        iconAnchor: [40, 10]
    });
    
    const russiaLabel = L.divIcon({
        className: 'arrow-label',
        html: `${attackData.russia.bandwidth} Gbps`,
        iconSize: [80, 20],
        iconAnchor: [40, 10]
    });
    
    // Place labels at midpoint of paths
    L.marker([49, -45], { icon: chinaLabel }).addTo(map);
    L.marker([47, -35], { icon: russiaLabel }).addTo(map);
    
    // Animate path dashes
    animatePaths();
}

// Add pulsing effect to map markers
function addPulsingEffect(marker, color) {
    const pulsingIcon = L.divIcon({
        className: 'pulsing-marker',
        html: `<div style="
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: ${color};
            opacity: 0.8;
            animation: pulse 2s infinite;
            border: 3px solid white;
            box-shadow: 0 0 20px ${color};
        "></div>`,
        iconSize: [40, 40],
        iconAnchor: [20, 20]
    });
    
    marker.setIcon(pulsingIcon);
}

// Animate attack paths
function animatePaths() {
    attackPaths.forEach(path => {
        const element = path.getElement();
        if (element) {
            element.style.strokeDashoffset = '0';
            anime({
                targets: element,
                strokeDashoffset: -25,
                duration: 1500,
                easing: 'linear',
                loop: true
            });
        }
    });
}

// Start packet flow animation
function startPacketFlow() {
    if (!attackData.china || !attackData.russia || !attackData.server) return;
    
    setInterval(() => {
        createPacket(attackData.china.location, attackData.server.location, 'china');
        createPacket(attackData.russia.location, attackData.server.location, 'russia');
    }, 800);
}

// Create animated packet
function createPacket(from, to, source) {
    const packet = L.circleMarker(from, {
        radius: 6,
        color: '#00ff88',
        fillColor: '#00ff88',
        fillOpacity: 1,
        weight: 2
    }).addTo(map);
    
    // Animate packet movement
    const animation = anime({
        targets: packet,
        lat: to[0],
        lng: to[1],
        duration: 2500,
        easing: 'easeInOutQuad',
        complete: () => {
            map.removeLayer(packet);
            // Create explosion effect at destination
            createExplosionEffect(to);
        }
    });
    
    packetAnimations.push(animation);
}

// Create explosion effect at destination
function createExplosionEffect(location) {
    const explosion = L.circleMarker(location, {
        radius: 20,
        color: '#ffa502',
        fillColor: '#ffa502',
        fillOpacity: 0.8,
        weight: 3
    }).addTo(map);
    
    anime({
        targets: explosion,
        radius: [20, 40, 0],
        opacity: [1, 0.8, 0],
        duration: 1000,
        easing: 'easeOutQuad',
        complete: () => {
            map.removeLayer(explosion);
        }
    });
}

// Initialize charts
function initializeCharts() {
    initializeTimelineChart();
    initializeBandwidthChart();
}

// Initialize timeline chart
function initializeTimelineChart() {
    const chartDom = document.getElementById('timeline-chart');
    timelineChart = echarts.init(chartDom);
    
    const option = {
        backgroundColor: 'transparent',
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: ['00:00', '00:05', '00:10', '00:15', '00:20', '00:25', '00:30'],
            axisLine: { lineStyle: { color: '#8892b0' } },
            axisLabel: { color: '#8892b0', fontSize: 10 }
        },
        yAxis: {
            type: 'value',
            axisLine: { lineStyle: { color: '#8892b0' } },
            axisLabel: { color: '#8892b0', fontSize: 10 },
            splitLine: { lineStyle: { color: '#333' } }
        },
        series: [
            {
                name: 'China Attack',
                type: 'line',
                data: [0, 0.5, 1.2, 2.3, 2.1, 2.3, 2.3],
                lineStyle: { color: '#ff4757', width: 3 },
                itemStyle: { color: '#ff4757' },
                areaStyle: { color: 'rgba(255, 71, 87, 0.1)' },
                smooth: true
            },
            {
                name: 'Russia Attack',
                type: 'line',
                data: [0, 0, 0.3, 0.8, 1.5, 1.8, 1.8],
                lineStyle: { color: '#ff6b35', width: 3 },
                itemStyle: { color: '#ff6b35' },
                areaStyle: { color: 'rgba(255, 107, 53, 0.1)' },
                smooth: true
            }
        ],
        tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(26, 29, 41, 0.9)',
            borderColor: '#00d4ff',
            textStyle: { color: '#e0e6ed' }
        }
    };
    
    timelineChart.setOption(option);
}

// Initialize bandwidth chart
function initializeBandwidthChart() {
    const chartDom = document.getElementById('bandwidth-chart');
    bandwidthChart = echarts.init(chartDom);
    
    const option = {
        backgroundColor: 'transparent',
        title: {
            text: 'Real-time Bandwidth Usage',
            textStyle: { color: '#e0e6ed', fontSize: 14 },
            left: 'center'
        },
        tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(26, 29, 41, 0.9)',
            borderColor: '#00d4ff',
            textStyle: { color: '#e0e6ed' }
        },
        legend: {
            data: ['China Attack', 'Russia Attack', 'Total Traffic'],
            textStyle: { color: '#8892b0' },
            bottom: 10
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '15%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: [],
            axisLine: { lineStyle: { color: '#8892b0' } },
            axisLabel: { color: '#8892b0' }
        },
        yAxis: {
            type: 'value',
            name: 'Gbps',
            nameTextStyle: { color: '#8892b0' },
            axisLine: { lineStyle: { color: '#8892b0' } },
            axisLabel: { color: '#8892b0' },
            splitLine: { lineStyle: { color: '#333' } }
        },
        series: [
            {
                name: 'China Attack',
                type: 'line',
                data: [],
                lineStyle: { color: '#ff4757', width: 3 },
                itemStyle: { color: '#ff4757' },
                areaStyle: { color: 'rgba(255, 71, 87, 0.2)' },
                smooth: true
            },
            {
                name: 'Russia Attack',
                type: 'line',
                data: [],
                lineStyle: { color: '#ff6b35', width: 3 },
                itemStyle: { color: '#ff6b35' },
                areaStyle: { color: 'rgba(255, 107, 53, 0.2)' },
                smooth: true
            },
            {
                name: 'Total Traffic',
                type: 'line',
                data: [],
                lineStyle: { color: '#00d4ff', width: 2 },
                itemStyle: { color: '#00d4ff' },
                areaStyle: { color: 'rgba(0, 212, 255, 0.1)' },
                smooth: true
            }
        ]
    };
    
    bandwidthChart.setOption(option);
}

// Start real-time updates
function startRealTimeUpdates() {
    // Update metrics every 2 seconds
    setInterval(updateMetrics, CONFIG.updateInterval);
    
    // Update charts every 5 seconds
    setInterval(updateCharts, CONFIG.chartUpdateInterval);
}

// Update real-time metrics
async function updateMetrics() {
    if (CONFIG.useRealData) {
        try {
            const response = await fetch(CONFIG.apiEndpoints.attackData);
            if (response.ok) {
                const newData = await response.json();
                attackData = { ...attackData, ...newData };
                updateDashboardWithRealData(attackData);
            }
        } catch (error) {
            console.error('Error updating metrics:', error);
        }
    } else {
        updateMockMetrics();
    }
}

// Update mock metrics
function updateMockMetrics() {
    // Simulate slight variations in attack data
    const chinaVariation = (Math.random() - 0.5) * 0.2;
    const russiaVariation = (Math.random() - 0.5) * 0.2;
    const cpuVariation = (Math.random() - 0.5) * 5;
    
    attackData.china.bandwidth = Math.max(1.5, attackData.china.bandwidth + chinaVariation);
    attackData.russia.bandwidth = Math.max(1.0, attackData.russia.bandwidth + russiaVariation);
    attackData.server.cpu = Math.max(40, Math.min(90, attackData.server.cpu + cpuVariation));
    
    // Update DOM elements with animation
    animateValue('china-bandwidth', attackData.china.bandwidth.toFixed(1));
    animateValue('russia-bandwidth', attackData.russia.bandwidth.toFixed(1));
    animateValue('server-load', Math.round(attackData.server.cpu));
    
    // Update packet counters with realistic fluctuations
    const chinaPackets = 45000 + Math.floor(Math.random() * 4000 - 2000);
    const russiaPackets = 38000 + Math.floor(Math.random() * 4000 - 2000);
    const totalBlocked = 1247832 + Math.floor(Math.random() * 2000);
    
    const chinaPacketsElement = document.getElementById('china-packets');
    const russiaPacketsElement = document.getElementById('russia-packets');
    
    if (chinaPacketsElement) chinaPacketsElement.textContent = chinaPackets.toLocaleString();
    if (russiaPacketsElement) russiaPacketsElement.textContent = russiaPackets.toLocaleString();
    
    // Update active threats counter
    const activeThreats = Math.floor(Math.random() * 3) + 1;
    document.getElementById('active-threats').textContent = activeThreats;
    
    // Update attack duration
    const now = new Date();
    const duration = Math.floor((now - new Date(now.getTime() - 18.5 * 60000)) / 60000);
    const minutes = Math.floor(duration);
    const seconds = Math.floor((duration - minutes) * 60);
    
    const durationElement = document.querySelector('.jetbrains.text-orange-400');
    if (durationElement) {
        durationElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
}

// Animate value changes
function animateValue(elementId, newValue) {
    const element = document.getElementById(elementId);
    if (element) {
        anime({
            targets: element,
            innerHTML: [element.innerHTML, newValue],
            duration: 1000,
            easing: 'easeOutQuad',
            round: elementId === 'server-load' ? 1 : 10
        });
    }
}

// Update charts with new data
async function updateCharts() {
    if (CONFIG.useRealData) {
        try {
            const response = await fetch(CONFIG.apiEndpoints.historicalData);
            if (response.ok) {
                const newHistoricalData = await response.json();
                updateChartsWithRealData(newHistoricalData);
            }
        } catch (error) {
            console.error('Error updating charts:', error);
        }
    } else {
        updateChartsWithMockData();
    }
}

// Update charts with mock data
function updateChartsWithMockData() {
    const currentTime = new Date().toLocaleTimeString('en-US', { 
        hour12: false,
        hour: '2-digit',
        minute: '2-digit'
    });
    
    // Update bandwidth chart
    const bandwidthOption = bandwidthChart.getOption();
    const newChinaData = attackData.china.bandwidth;
    const newRussiaData = attackData.russia.bandwidth;
    const totalData = newChinaData + newRussiaData;
    
    bandwidthOption.xAxis[0].data.push(currentTime);
    bandwidthOption.series[0].data.push(newChinaData);
    bandwidthOption.series[1].data.push(newRussiaData);
    bandwidthOption.series[2].data.push(totalData);
    
    // Keep only last 20 data points
    if (bandwidthOption.xAxis[0].data.length > 20) {
        bandwidthOption.xAxis[0].data.shift();
        bandwidthOption.series[0].data.shift();
        bandwidthOption.series[1].data.shift();
        bandwidthOption.series[2].data.shift();
    }
    
    bandwidthChart.setOption(bandwidthOption);
}

// Initialize interactive elements
function initializeInteractiveElements() {
    // Add click handlers for response action buttons
    document.querySelectorAll('.response-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const action = e.target.dataset.action;
            
            // Add click animation
            anime({
                targets: e.target,
                scale: [1, 0.95, 1],
                duration: 200,
                easing: 'easeInOutQuad'
            });
            
            // Handle different button actions
            switch (action) {
                case 'shield':
                    showNotification('DDoS Shield activated! All incoming traffic is being filtered.', 'success');
                    break;
                case 'team':
                    showNotification('Security team has been notified and is responding to the incident.', 'info');
                    break;
                case 'report':
                    showNotification('Incident report is being generated and will be available shortly.', 'info');
                    break;
                case 'blackhole':
                    if (confirm('Are you sure you want to activate emergency blackhole? This will block all traffic.')) {
                        showNotification('Emergency blackhole activated! All traffic is being dropped.', 'error');
                    }
                    break;
            }
        });
    });
    
    // Add click handlers for time range buttons
    document.querySelectorAll('.time-range-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const range = e.target.dataset.range;
            
            // Update button states
            document.querySelectorAll('.time-range-btn').forEach(btn => {
                btn.classList.remove('bg-blue-600');
                btn.classList.add('bg-gray-700');
            });
            e.target.classList.remove('bg-gray-700');
            e.target.classList.add('bg-blue-600');
            
            showNotification(`Switched to ${range} view`, 'info');
        });
    });
    
    // Add hover effects for cards
    document.querySelectorAll('.cyber-card').forEach(card => {
        card.addEventListener('mouseenter', () => {
            anime({
                targets: card,
                scale: 1.02,
                duration: 300,
                easing: 'easeOutQuad'
            });
        });
        
        card.addEventListener('mouseleave', () => {
            anime({
                targets: card,
                scale: 1,
                duration: 300,
                easing: 'easeOutQuad'
            });
        });
    });
}

// Enhanced notification system
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `fixed top-20 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm ${
        type === 'success' ? 'bg-green-600' :
        type === 'warning' ? 'bg-yellow-600' :
        type === 'error' ? 'bg-red-600' :
        'bg-blue-600'
    }`;
    
    notification.innerHTML = `
        <div class="flex items-center space-x-2">
            <span class="text-sm font-medium">${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-2 text-white hover:text-gray-200 text-lg">&times;</button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    anime({
        targets: notification,
        translateX: [300, 0],
        opacity: [0, 1],
        duration: 300,
        easing: 'easeOutQuad'
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            anime({
                targets: notification,
                translateX: [0, 300],
                opacity: [1, 0],
                duration: 300,
                easing: 'easeInQuad',
                complete: () => {
                    notification.remove();
                }
            });
        }
    }, 5000);
}

// Initialize animations
function initializeAnimations() {
    // Animate cards on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                anime({
                    targets: entry.target,
                    translateY: [50, 0],
                    opacity: [0, 1],
                    duration: 800,
                    easing: 'easeOutQuad',
                    delay: anime.stagger(200)
                });
            }
        });
    }, observerOptions);
    
    // Observe all cyber cards
    document.querySelectorAll('.cyber-card').forEach(card => {
        observer.observe(card);
    });
    
    // Add hover effects to buttons
    document.querySelectorAll('button').forEach(button => {
        button.addEventListener('mouseenter', () => {
            anime({
                targets: button,
                scale: 1.05,
                duration: 200,
                easing: 'easeOutQuad'
            });
        });
        
        button.addEventListener('mouseleave', () => {
            anime({
                targets: button,
                scale: 1,
                duration: 200,
                easing: 'easeOutQuad'
            });
        });
    });
    
    // Animate metric numbers on load
    anime({
        targets: '.metric-number',
        scale: [0, 1],
        opacity: [0, 1],
        duration: 1000,
        easing: 'easeOutElastic(1, .8)',
        delay: anime.stagger(200)
    });
}

// Time display
function initializeTime() {
    function updateTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { 
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        const dateString = now.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric'
        });
        
        const timeElement = document.getElementById('current-time');
        if (timeElement) {
            timeElement.textContent = `${dateString} ${timeString}`;
        }
    }
    
    updateTime();
    setInterval(updateTime, 1000);
}

// Hero text animations
function initializeHeroText() {
    // Splitting.js for text animation
    Splitting();
    
    // Typed.js for subtitle
    const typed = new Typed('#hero-subtitle', {
        strings: [
            'Real-time DDoS attack monitoring',
            'Advanced threat detection systems',
            'Global attack visualization network',
            '24/7 security operations center',
            'AI-powered threat intelligence'
        ],
        typeSpeed: 50,
        backSpeed: 30,
        backDelay: 2000,
        loop: true
    });
    
    // Animate hero title
    anime({
        targets: '[data-splitting] .char',
        translateY: [-100, 0],
        opacity: [0, 1],
        easing: 'easeOutExpo',
        duration: 1400,
        delay: anime.stagger(100)
    });
}

// Handle window resize
window.addEventListener('resize', () => {
    if (timelineChart) timelineChart.resize();
    if (bandwidthChart) bandwidthChart.resize();
    if (map) map.invalidateSize();
});

// Cleanup animations on page unload
window.addEventListener('beforeunload', () => {
    packetAnimations.forEach(animation => {
        if (animation.pause) animation.pause();
    });
});