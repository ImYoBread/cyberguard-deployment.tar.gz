// CyberGuard DDoS Monitoring Dashboard - Enhanced JavaScript

// Global variables
let map;
let attackPaths = [];
let packetAnimations = [];
let timelineChart;
let bandwidthChart;
let threatLevelChart;

// Enhanced mock attack data
const attackData = {
    china: {
        location: [39.9042, 116.4074], // Beijing
        bandwidth: 2.3,
        packets: 45000,
        ipRange: "203.208.60.0/24",
        status: "critical",
        duration: 18,
        attackVectors: { udp: 65, tcp: 25, http: 8, icmp: 2 }
    },
    russia: {
        location: [55.7558, 37.6176], // Moscow
        bandwidth: 1.8,
        packets: 38000,
        ipRange: "95.213.128.0/24",
        status: "critical",
        duration: 12,
        attackVectors: { udp: 55, tcp: 30, http: 12, icmp: 3 }
    },
    server: {
        location: [37.5407, -77.4360], // Virginia
        ip: "10.0.0.1",
        cpu: 65,
        status: "mitigating",
        responseTime: 2.1,
        blockedIPs: 247,
        uptime: 99.8
    }
};

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    initializeTime();
    initializeHeroText();
    initializeMap();
    initializeCharts();
    startRealTimeUpdates();
    initializeAnimations();
    initializeInteractiveElements();
});

// Time display
function initializeTime() {
    function updateTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { 
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        const dateString = now.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric'
        });
        
        const timeElement = document.getElementById('current-time');
        if (timeElement) {
            timeElement.textContent = `${dateString} ${timeString}`;
        }
    }
    
    updateTime();
    setInterval(updateTime, 1000);
}

// Hero text animations
function initializeHeroText() {
    // Splitting.js for text animation
    Splitting();
    
    // Typed.js for subtitle
    const typed = new Typed('#hero-subtitle', {
        strings: [
            'Real-time DDoS attack monitoring',
            'Advanced threat detection systems',
            'Global attack visualization network',
            '24/7 security operations center',
            'AI-powered threat intelligence'
        ],
        typeSpeed: 50,
        backSpeed: 30,
        backDelay: 2000,
        loop: true
    });
    
    // Animate hero title
    anime({
        targets: '[data-splitting] .char',
        translateY: [-100, 0],
        opacity: [0, 1],
        easing: 'easeOutExpo',
        duration: 1400,
        delay: anime.stagger(100)
    });
}

// Initialize world map
function initializeMap() {
    // Initialize Leaflet map
    map = L.map('map', {
        center: [30, 0],
        zoom: 2,
        zoomControl: false,
        attributionControl: false
    });
    
    // Add dark tile layer
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd'
    }).addTo(map);
    
    // Add attack locations
    addAttackMarkers();
    
    // Create attack paths
    createAttackPaths();
    
    // Start packet flow animation
    startPacketFlow();
}

// Add attack markers to map
function addAttackMarkers() {
    // China attack marker
    const chinaMarker = L.circleMarker(attackData.china.location, {
        radius: 15,
        color: '#ff4757',
        fillColor: '#ff4757',
        fillOpacity: 0.8,
        weight: 3
    }).addTo(map);
    
    chinaMarker.bindPopup(`
        <div class="text-gray-800 p-2">
            <h3 class="font-bold text-red-600 mb-2">🇨🇳 China Attack</h3>
            <div class="space-y-1 text-sm">
                <p><strong>Location:</strong> Beijing</p>
                <p><strong>Bandwidth:</strong> ${attackData.china.bandwidth} Gbps</p>
                <p><strong>Packets:</strong> ${attackData.china.packets.toLocaleString()}/sec</p>
                <p><strong>IP Range:</strong> ${attackData.china.ipRange}</p>
                <p><strong>Duration:</strong> ${attackData.china.duration} min</p>
                <div class="mt-2 pt-2 border-t">
                    <p class="text-xs"><strong>Attack Vectors:</strong></p>
                    <p class="text-xs">UDP Flood: ${attackData.china.attackVectors.udp}%</p>
                    <p class="text-xs">TCP SYN: ${attackData.china.attackVectors.tcp}%</p>
                </div>
            </div>
        </div>
    `);
    
    // Russia attack marker
    const russiaMarker = L.circleMarker(attackData.russia.location, {
        radius: 15,
        color: '#ff4757',
        fillColor: '#ff4757',
        fillOpacity: 0.8,
        weight: 3
    }).addTo(map);
    
    russiaMarker.bindPopup(`
        <div class="text-gray-800 p-2">
            <h3 class="font-bold text-red-600 mb-2">🇷🇺 Russia Attack</h3>
            <div class="space-y-1 text-sm">
                <p><strong>Location:</strong> Moscow</p>
                <p><strong>Bandwidth:</strong> ${attackData.russia.bandwidth} Gbps</p>
                <p><strong>Packets:</strong> ${attackData.russia.packets.toLocaleString()}/sec</p>
                <p><strong>IP Range:</strong> ${attackData.russia.ipRange}</p>
                <p><strong>Duration:</strong> ${attackData.russia.duration} min</p>
                <div class="mt-2 pt-2 border-t">
                    <p class="text-xs"><strong>Attack Vectors:</strong></p>
                    <p class="text-xs">UDP Flood: ${attackData.russia.attackVectors.udp}%</p>
                    <p class="text-xs">TCP SYN: ${attackData.russia.attackVectors.tcp}%</p>
                </div>
            </div>
        </div>
    `);
    
    // Server marker
    const serverMarker = L.circleMarker(attackData.server.location, {
        radius: 18,
        color: '#00d4ff',
        fillColor: '#00d4ff',
        fillOpacity: 0.8,
        weight: 3
    }).addTo(map);
    
    serverMarker.bindPopup(`
        <div class="text-gray-800 p-2">
            <h3 class="font-bold text-blue-600 mb-2">🖥️ OVH Virginia Server</h3>
            <div class="space-y-1 text-sm">
                <p><strong>IP:</strong> ${attackData.server.ip}</p>
                <p><strong>CPU Usage:</strong> ${attackData.server.cpu}%</p>
                <p><strong>Response Time:</strong> ${attackData.server.responseTime}ms</p>
                <p><strong>Blocked IPs:</strong> ${attackData.server.blockedIPs}</p>
                <p><strong>Uptime:</strong> ${attackData.server.uptime}%</p>
                <p><strong>Status:</strong> <span class="text-orange-600">Mitigating Attack</span></p>
            </div>
        </div>
    `);
    
    // Add pulsing effect to markers
    addPulsingEffect(chinaMarker, '#ff4757');
    addPulsingEffect(russiaMarker, '#ff4757');
    addPulsingEffect(serverMarker, '#00d4ff');
}

// Add pulsing effect to map markers
function addPulsingEffect(marker, color) {
    const pulsingIcon = L.divIcon({
        className: 'pulsing-marker',
        html: `<div style="
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: ${color};
            opacity: 0.8;
            animation: pulse 2s infinite;
            border: 3px solid white;
            box-shadow: 0 0 20px ${color};
        "></div>`,
        iconSize: [40, 40],
        iconAnchor: [20, 20]
    });
    
    marker.setIcon(pulsingIcon);
}

// Create attack paths on map
function createAttackPaths() {
    // China to Virginia path with curved routing
    const chinaPath = L.polyline([
        attackData.china.location,
        [60, -30], // Midpoint 1
        [50, -60], // Midpoint 2
        [45, -70], // Midpoint 3
        attackData.server.location
    ], {
        color: '#ff4757',
        weight: 4,
        opacity: 0.9,
        dashArray: '15, 10'
    }).addTo(map);
    
    // Russia to Virginia path with curved routing
    const russiaPath = L.polyline([
        attackData.russia.location,
        [50, -20], // Midpoint 1
        [45, -50], // Midpoint 2
        [40, -65], // Midpoint 3
        attackData.server.location
    ], {
        color: '#ff4757',
        weight: 4,
        opacity: 0.9,
        dashArray: '15, 10'
    }).addTo(map);
    
    attackPaths.push(chinaPath, russiaPath);
    
    // Animate path dashes
    animatePaths();
}

// Animate attack paths
function animatePaths() {
    attackPaths.forEach(path => {
        const element = path.getElement();
        if (element) {
            element.style.strokeDashoffset = '0';
            anime({
                targets: element,
                strokeDashoffset: -25,
                duration: 1500,
                easing: 'linear',
                loop: true
            });
        }
    });
}

// Start packet flow animation
function startPacketFlow() {
    setInterval(() => {
        createPacket(attackData.china.location, attackData.server.location, 'china');
        createPacket(attackData.russia.location, attackData.server.location, 'russia');
    }, 800);
}

// Create animated packet
function createPacket(from, to, source) {
    const packet = L.circleMarker(from, {
        radius: 6,
        color: '#00ff88',
        fillColor: '#00ff88',
        fillOpacity: 1,
        weight: 2
    }).addTo(map);
    
    // Animate packet movement
    const animation = anime({
        targets: packet,
        lat: to[0],
        lng: to[1],
        duration: 2500,
        easing: 'easeInOutQuad',
        complete: () => {
            map.removeLayer(packet);
            // Create explosion effect at destination
            createExplosionEffect(to);
        }
    });
    
    packetAnimations.push(animation);
}

// Create explosion effect at destination
function createExplosionEffect(location) {
    const explosion = L.circleMarker(location, {
        radius: 20,
        color: '#ffa502',
        fillColor: '#ffa502',
        fillOpacity: 0.8,
        weight: 3
    }).addTo(map);
    
    anime({
        targets: explosion,
        radius: [20, 40, 0],
        opacity: [1, 0.8, 0],
        duration: 1000,
        easing: 'easeOutQuad',
        complete: () => {
            map.removeLayer(explosion);
        }
    });
}

// Initialize charts
function initializeCharts() {
    initializeTimelineChart();
    initializeBandwidthChart();
    initializeThreatLevelChart();
}

// Initialize timeline chart
function initializeTimelineChart() {
    const chartDom = document.getElementById('timeline-chart');
    timelineChart = echarts.init(chartDom);
    
    const option = {
        backgroundColor: 'transparent',
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: ['00:00', '00:05', '00:10', '00:15', '00:20', '00:25', '00:30'],
            axisLine: { lineStyle: { color: '#8892b0' } },
            axisLabel: { color: '#8892b0', fontSize: 10 }
        },
        yAxis: {
            type: 'value',
            axisLine: { lineStyle: { color: '#8892b0' } },
            axisLabel: { color: '#8892b0', fontSize: 10 },
            splitLine: { lineStyle: { color: '#333' } }
        },
        series: [
            {
                name: 'China Attack',
                type: 'line',
                data: [0, 0.5, 1.2, 2.3, 2.1, 2.3, 2.3],
                lineStyle: { color: '#ff4757', width: 3 },
                itemStyle: { color: '#ff4757' },
                areaStyle: { color: 'rgba(255, 71, 87, 0.1)' },
                smooth: true
            },
            {
                name: 'Russia Attack',
                type: 'line',
                data: [0, 0, 0.3, 0.8, 1.5, 1.8, 1.8],
                lineStyle: { color: '#ff6b35', width: 3 },
                itemStyle: { color: '#ff6b35' },
                areaStyle: { color: 'rgba(255, 107, 53, 0.1)' },
                smooth: true
            }
        ],
        tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(26, 29, 41, 0.9)',
            borderColor: '#00d4ff',
            textStyle: { color: '#e0e6ed' }
        }
    };
    
    timelineChart.setOption(option);
}

// Initialize bandwidth chart
function initializeBandwidthChart() {
    const chartDom = document.getElementById('bandwidth-chart');
    bandwidthChart = echarts.init(chartDom);
    
    const option = {
        backgroundColor: 'transparent',
        title: {
            text: 'Real-time Bandwidth Usage',
            textStyle: { color: '#e0e6ed', fontSize: 14 },
            left: 'center'
        },
        tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(26, 29, 41, 0.9)',
            borderColor: '#00d4ff',
            textStyle: { color: '#e0e6ed' }
        },
        legend: {
            data: ['China Attack', 'Russia Attack', 'Total Traffic'],
            textStyle: { color: '#8892b0' },
            bottom: 10
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '15%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: [],
            axisLine: { lineStyle: { color: '#8892b0' } },
            axisLabel: { color: '#8892b0' }
        },
        yAxis: {
            type: 'value',
            name: 'Gbps',
            nameTextStyle: { color: '#8892b0' },
            axisLine: { lineStyle: { color: '#8892b0' } },
            axisLabel: { color: '#8892b0' },
            splitLine: { lineStyle: { color: '#333' } }
        },
        series: [
            {
                name: 'China Attack',
                type: 'line',
                data: [],
                lineStyle: { color: '#ff4757', width: 3 },
                itemStyle: { color: '#ff4757' },
                areaStyle: { color: 'rgba(255, 71, 87, 0.2)' },
                smooth: true
            },
            {
                name: 'Russia Attack',
                type: 'line',
                data: [],
                lineStyle: { color: '#ff6b35', width: 3 },
                itemStyle: { color: '#ff6b35' },
                areaStyle: { color: 'rgba(255, 107, 53, 0.2)' },
                smooth: true
            },
            {
                name: 'Total Traffic',
                type: 'line',
                data: [],
                lineStyle: { color: '#00d4ff', width: 2 },
                itemStyle: { color: '#00d4ff' },
                areaStyle: { color: 'rgba(0, 212, 255, 0.1)' },
                smooth: true
            }
        ]
    };
    
    bandwidthChart.setOption(option);
}

// Initialize threat level chart
function initializeThreatLevelChart() {
    const chartDom = document.getElementById('threat-level-chart');
    if (chartDom) {
        threatLevelChart = echarts.init(chartDom);
        
        const option = {
            backgroundColor: 'transparent',
            series: [
                {
                    type: 'gauge',
                    center: ['50%', '60%'],
                    startAngle: 200,
                    endAngle: -40,
                    min: 0,
                    max: 100,
                    splitNumber: 10,
                    itemStyle: {
                        color: '#ff4757'
                    },
                    progress: {
                        show: true,
                        width: 18
                    },
                    pointer: {
                        show: false
                    },
                    axisLine: {
                        lineStyle: {
                            width: 18,
                            color: [[1, '#333']]
                        }
                    },
                    axisTick: {
                        distance: -30,
                        splitNumber: 5,
                        lineStyle: {
                            width: 2,
                            color: '#999'
                        }
                    },
                    splitLine: {
                        distance: -30,
                        length: 14,
                        lineStyle: {
                            width: 3,
                            color: '#999'
                        }
                    },
                    axisLabel: {
                        distance: -20,
                        color: '#999',
                        fontSize: 12
                    },
                    anchor: {
                        show: false
                    },
                    title: {
                        show: false
                    },
                    detail: {
                        valueAnimation: true,
                        width: '60%',
                        lineHeight: 40,
                        borderRadius: 8,
                        offsetCenter: [0, '-15%'],
                        fontSize: 20,
                        fontWeight: 'bold',
                        formatter: '{value}%',
                        color: '#ff4757'
                    },
                    data: [
                        {
                            value: 85,
                            name: 'Threat Level'
                        }
                    ]
                }
            ]
        };
        
        threatLevelChart.setOption(option);
    }
}

// Start real-time updates
function startRealTimeUpdates() {
    // Update metrics every 2 seconds
    setInterval(updateMetrics, 2000);
    
    // Update charts every 5 seconds
    setInterval(updateCharts, 5000);
    
    // Update threat level every 10 seconds
    setInterval(updateThreatLevel, 10000);
}

// Update real-time metrics
function updateMetrics() {
    // Simulate slight variations in attack data
    const chinaVariation = (Math.random() - 0.5) * 0.2;
    const russiaVariation = (Math.random() - 0.5) * 0.2;
    const cpuVariation = (Math.random() - 0.5) * 5;
    
    attackData.china.bandwidth = Math.max(1.5, attackData.china.bandwidth + chinaVariation);
    attackData.russia.bandwidth = Math.max(1.0, attackData.russia.bandwidth + russiaVariation);
    attackData.server.cpu = Math.max(40, Math.min(90, attackData.server.cpu + cpuVariation));
    
    // Update DOM elements with animation
    animateValue('china-bandwidth', attackData.china.bandwidth.toFixed(1));
    animateValue('russia-bandwidth', attackData.russia.bandwidth.toFixed(1));
    animateValue('server-load', Math.round(attackData.server.cpu));
    
    // Update packet counters with realistic fluctuations
    const chinaPackets = 45000 + Math.floor(Math.random() * 4000 - 2000);
    const russiaPackets = 38000 + Math.floor(Math.random() * 4000 - 2000);
    const totalBlocked = 1247832 + Math.floor(Math.random() * 2000);
    
    document.getElementById('china-packets').textContent = chinaPackets.toLocaleString();
    document.getElementById('russia-packets').textContent = russiaPackets.toLocaleString();
    document.getElementById('total-blocked').textContent = totalBlocked.toLocaleString();
    
    // Update active threats counter
    const activeThreats = Math.floor(Math.random() * 3) + 1;
    document.getElementById('active-threats').textContent = activeThreats;
    
    // Update attack duration
    const now = new Date();
    const duration = Math.floor((now - new Date(now.getTime() - 18.5 * 60000)) / 60000);
    const minutes = Math.floor(duration);
    const seconds = Math.floor((duration - minutes) * 60);
    document.querySelector('.jetbrains.text-orange-400').textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

// Animate value changes
function animateValue(elementId, newValue) {
    const element = document.getElementById(elementId);
    if (element) {
        anime({
            targets: element,
            innerHTML: [element.innerHTML, newValue],
            duration: 1000,
            easing: 'easeOutQuad',
            round: elementId === 'server-load' ? 1 : 10
        });
    }
}

// Update charts with new data
function updateCharts() {
    const currentTime = new Date().toLocaleTimeString('en-US', { 
        hour12: false,
        hour: '2-digit',
        minute: '2-digit'
    });
    
    // Update bandwidth chart
    const bandwidthOption = bandwidthChart.getOption();
    const newChinaData = attackData.china.bandwidth;
    const newRussiaData = attackData.russia.bandwidth;
    const totalData = newChinaData + newRussiaData;
    
    bandwidthOption.xAxis[0].data.push(currentTime);
    bandwidthOption.series[0].data.push(newChinaData);
    bandwidthOption.series[1].data.push(newRussiaData);
    bandwidthOption.series[2].data.push(totalData);
    
    // Keep only last 20 data points
    if (bandwidthOption.xAxis[0].data.length > 20) {
        bandwidthOption.xAxis[0].data.shift();
        bandwidthOption.series[0].data.shift();
        bandwidthOption.series[1].data.shift();
        bandwidthOption.series[2].data.shift();
    }
    
    bandwidthChart.setOption(bandwidthOption);
}

// Update threat level
function updateThreatLevel() {
    if (threatLevelChart) {
        const threatLevel = Math.floor(Math.random() * 20) + 75; // 75-95%
        
        threatLevelChart.setOption({
            series: [{
                data: [{
                    value: threatLevel,
                    name: 'Threat Level'
                }]
            }]
        });
    }
}

// Initialize interactive elements
function initializeInteractiveElements() {
    // Add click handlers for response action buttons
    document.querySelectorAll('button').forEach(button => {
        button.addEventListener('click', (e) => {
            const buttonText = e.target.textContent.trim();
            
            // Add click animation
            anime({
                targets: e.target,
                scale: [1, 0.95, 1],
                duration: 200,
                easing: 'easeInOutQuad'
            });
            
            // Handle different button actions
            switch (buttonText) {
                case 'Activate DDoS Shield':
                    showNotification('DDoS Shield activated! All incoming traffic is being filtered.', 'success');
                    break;
                case 'Contact Security Team':
                    showNotification('Security team has been notified and is responding to the incident.', 'info');
                    break;
                case 'Generate Incident Report':
                    showNotification('Incident report is being generated and will be available shortly.', 'info');
                    break;
                case 'Emergency Blackhole':
                    if (confirm('Are you sure you want to activate emergency blackhole? This will block all traffic.')) {
                        showNotification('Emergency blackhole activated! All traffic is being dropped.', 'error');
                    }
                    break;
                case '1H':
                case '6H':
                case '24H':
                    // Handle time range buttons
                    document.querySelectorAll('button').forEach(btn => {
                        if (['1H', '6H', '24H'].includes(btn.textContent.trim())) {
                            btn.classList.remove('bg-blue-600');
                            btn.classList.add('bg-gray-700');
                        }
                    });
                    e.target.classList.remove('bg-gray-700');
                    e.target.classList.add('bg-blue-600');
                    showNotification(`Switched to ${buttonText} view`, 'info');
                    break;
            }
        });
    });
    
    // Add hover effects for cards
    document.querySelectorAll('.cyber-card').forEach(card => {
        card.addEventListener('mouseenter', () => {
            anime({
                targets: card,
                scale: 1.02,
                duration: 300,
                easing: 'easeOutQuad'
            });
        });
        
        card.addEventListener('mouseleave', () => {
            anime({
                targets: card,
                scale: 1,
                duration: 300,
                easing: 'easeOutQuad'
            });
        });
    });
}

// Enhanced notification system
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `fixed top-20 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm ${
        type === 'success' ? 'bg-green-600' :
        type === 'warning' ? 'bg-yellow-600' :
        type === 'error' ? 'bg-red-600' :
        'bg-blue-600'
    }`;
    
    notification.innerHTML = `
        <div class="flex items-center space-x-2">
            <span class="text-sm font-medium">${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-2 text-white hover:text-gray-200 text-lg">&times;</button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    anime({
        targets: notification,
        translateX: [300, 0],
        opacity: [0, 1],
        duration: 300,
        easing: 'easeOutQuad'
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            anime({
                targets: notification,
                translateX: [0, 300],
                opacity: [1, 0],
                duration: 300,
                easing: 'easeInQuad',
                complete: () => {
                    notification.remove();
                }
            });
        }
    }, 5000);
}

// Initialize animations
function initializeAnimations() {
    // Animate cards on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                anime({
                    targets: entry.target,
                    translateY: [50, 0],
                    opacity: [0, 1],
                    duration: 800,
                    easing: 'easeOutQuad',
                    delay: anime.stagger(200)
                });
            }
        });
    }, observerOptions);
    
    // Observe all cyber cards
    document.querySelectorAll('.cyber-card').forEach(card => {
        observer.observe(card);
    });
    
    // Add hover effects to buttons
    document.querySelectorAll('button').forEach(button => {
        button.addEventListener('mouseenter', () => {
            anime({
                targets: button,
                scale: 1.05,
                duration: 200,
                easing: 'easeOutQuad'
            });
        });
        
        button.addEventListener('mouseleave', () => {
            anime({
                targets: button,
                scale: 1,
                duration: 200,
                easing: 'easeOutQuad'
            });
        });
    });
    
    // Animate metric numbers on load
    anime({
        targets: '.metric-number',
        scale: [0, 1],
        opacity: [0, 1],
        duration: 1000,
        easing: 'easeOutElastic(1, .8)',
        delay: anime.stagger(200)
    });
}

// Handle window resize
window.addEventListener('resize', () => {
    if (timelineChart) timelineChart.resize();
    if (bandwidthChart) bandwidthChart.resize();
    if (threatLevelChart) threatLevelChart.resize();
    if (map) map.invalidateSize();
});

// Cleanup animations on page unload
window.addEventListener('beforeunload', () => {
    packetAnimations.forEach(animation => {
        if (animation.pause) animation.pause();
    });
});