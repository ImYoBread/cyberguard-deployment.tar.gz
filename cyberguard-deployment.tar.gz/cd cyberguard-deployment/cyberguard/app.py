#!/usr/bin/env python3
"""
CyberGuard DDoS Monitoring Dashboard
Flask Application with Real Data Integration
Author: CyberGuard Security Team
"""

import os
import json
import time
import random
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import threading
import requests
from collections import deque

app = Flask(__name__)
CORS(app)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'cyberguard-secret-key-2024')

# Global data storage
attack_data = {
    'china': {
        'location': [39.9042, 116.4074],
        'bandwidth': 2.3,
        'packets': 45000,
        'ip_range': '203.208.60.0/24',
        'status': 'critical',
        'duration': 18,
        'country': 'China',
        'city': 'Beijing'
    },
    'russia': {
        'location': [55.7558, 37.6176],
        'bandwidth': 1.8,
        'packets': 38000,
        'ip_range': '95.213.128.0/24',
        'status': 'critical',
        'duration': 12,
        'country': 'Russia',
        'city': 'Moscow'
    },
    'server': {
        'location': [37.5407, -77.4360],
        'ip': '10.0.0.1',
        'cpu': 65,
        'status': 'mitigating',
        'response_time': 2.1,
        'blocked_ips': 247,
        'uptime': 99.8,
        'name': 'OVH Virginia'
    }
}

# Historical data storage
historical_data = {
    'bandwidth': deque(maxlen=100),
    'timeline': deque(maxlen=50),
    'attacks': deque(maxlen=200)
}

# Real data sources configuration
REAL_DATA_SOURCES = {
    'enable_real_data': False,  # Set to True to enable real data sources
    'sources': {
        'netflow': {
            'enabled': False,
            'collector_ip': '0.0.0.0',
            'port': 9995,
            'bind_ip': '0.0.0.0'
        },
        'syslog': {
            'enabled': False,
            'port': 514,
            'bind_ip': '0.0.0.0'
        },
        'api_polling': {
            'enabled': False,
            'endpoints': [
                'http://localhost:8080/api/network/stats',
                'http://localhost:8080/api/security/alerts'
            ],
            'interval': 30  # seconds
        }
    }
}

def generate_mock_data():
    """Generate realistic mock attack data"""
    now = datetime.now()
    
    # Simulate bandwidth fluctuations
    china_bandwidth = max(1.5, attack_data['china']['bandwidth'] + (random.random() - 0.5) * 0.2)
    russia_bandwidth = max(1.0, attack_data['russia']['bandwidth'] + (random.random() - 0.5) * 0.2)
    
    # Update attack data
    attack_data['china']['bandwidth'] = china_bandwidth
    attack_data['russia']['bandwidth'] = russia_bandwidth
    attack_data['china']['packets'] = 45000 + random.randint(-2000, 2000)
    attack_data['russia']['packets'] = 38000 + random.randint(-2000, 2000)
    attack_data['server']['cpu'] = max(40, min(90, attack_data['server']['cpu'] + (random.random() - 0.5) * 5))
    
    # Store historical data
    historical_data['bandwidth'].append({
        'timestamp': now.isoformat(),
        'china': china_bandwidth,
        'russia': russia_bandwidth,
        'total': china_bandwidth + russia_bandwidth
    })
    
    historical_data['timeline'].append({
        'timestamp': now.isoformat(),
        'time': now.strftime('%H:%M'),
        'china': china_bandwidth,
        'russia': russia_bandwidth
    })
    
    # Generate attack log entry
    if random.random() < 0.1:  # 10% chance of new attack
        attack_type = random.choice(['UDP Flood', 'TCP SYN', 'HTTP Flood', 'ICMP Flood'])
        severity = random.choice(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'])
        
        historical_data['attacks'].append({
            'timestamp': now.isoformat(),
            'type': attack_type,
            'severity': severity,
            'source_country': random.choice(['China', 'Russia', 'USA', 'Brazil', 'India']),
            'bandwidth': round(random.uniform(0.1, 3.0), 2),
            'packets_per_second': random.randint(1000, 50000),
            'status': random.choice(['ACTIVE', 'MITIGATED', 'BLOCKED'])
        })

def simulate_real_data():
    """Simulate real data integration"""
    while True:
        if REAL_DATA_SOURCES['enable_real_data']:
            # In a real implementation, this would collect data from:
            # - NetFlow collectors
            # - Syslog servers
            # - API endpoints
            # - Network monitoring tools
            pass
        else:
            generate_mock_data()
        
        time.sleep(2)  # Update every 2 seconds

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('index.html')

@app.route('/analytics')
def analytics():
    """Analytics page"""
    return render_template('analytics.html')

@app.route('/settings')
def settings():
    """Settings page"""
    return render_template('settings.html')

@app.route('/api/attack-data')
def get_attack_data():
    """Get current attack data"""
    generate_mock_data()  # Update data before sending
    
    return jsonify({
        'china': attack_data['china'],
        'russia': attack_data['russia'],
        'server': attack_data['server'],
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/historical-data')
def get_historical_data():
    """Get historical attack data"""
    data_type = request.args.get('type', 'all')
    
    response = {
        'bandwidth': list(historical_data['bandwidth']),
        'timeline': list(historical_data['timeline']),
        'attacks': list(historical_data['attacks'])
    }
    
    if data_type != 'all':
        return jsonify({data_type: response.get(data_type, [])})
    
    return jsonify(response)

@app.route('/api/network-stats')
def get_network_stats():
    """Get network statistics"""
    return jsonify({
        'total_attacks_blocked': len(historical_data['attacks']),
        'peak_bandwidth': max([d['total'] for d in historical_data['bandwidth']]) if historical_data['bandwidth'] else 0,
        'avg_response_time': 2.3,
        'system_uptime': 99.8,
        'active_threats': random.randint(1, 5),
        'mitigated_attacks': sum(1 for attack in historical_data['attacks'] if attack['status'] == 'MITIGATED')
    })

@app.route('/api/configure-real-data', methods=['POST'])
def configure_real_data():
    """Configure real data sources"""
    config = request.json
    
    REAL_DATA_SOURCES.update(config)
    
    return jsonify({
        'status': 'success',
        'message': 'Real data configuration updated',
        'config': REAL_DATA_SOURCES
    })

@app.route('/api/test-connection')
def test_connection():
    """Test API connection"""
    return jsonify({
        'status': 'success',
        'message': 'CyberGuard API is running',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    # Start background thread for data simulation
    data_thread = threading.Thread(target=simulate_real_data, daemon=True)
    data_thread.start()
    
    # Run Flask application
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=False,
        threaded=True
    )