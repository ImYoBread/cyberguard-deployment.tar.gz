#!/bin/bash

# CyberGuard DDoS Monitoring Dashboard Installation Script
# For Ubuntu 22.04 LTS
# Author: CyberGuard Security Team

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
APP_NAME="cyberguard"
APP_DIR="/opt/cyberguard"
SERVICE_NAME="cyberguard"
USER_NAME="cyberguard"
VENV_DIR="$APP_DIR/venv"

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root (use sudo)"
        exit 1
    fi
}

# Function to check Ubuntu version
check_ubuntu() {
    if [[ ! -f /etc/os-release ]]; then
        print_error "Cannot determine OS version"
        exit 1
    fi
    
    . /etc/os-release
    if [[ "$ID" != "ubuntu" ]] || [[ "$VERSION_ID" != "22.04" ]]; then
        print_warning "This script is designed for Ubuntu 22.04 LTS"
        print_warning "Your system: $PRETTY_NAME"
        read -p "Continue anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
}

# Function to update system
update_system() {
    print_status "Updating system packages..."
    apt update && apt upgrade -y
    print_success "System updated successfully"
}

# Function to install dependencies
install_dependencies() {
    print_status "Installing system dependencies..."
    
    # Install Python and pip
    apt install -y python3 python3-pip python3-venv python3-dev
    
    # Install system tools
    apt install -y curl wget git nginx supervisor ufw fail2ban
    
    # Install build tools
    apt install -y build-essential libffi-dev libssl-dev
    
    print_success "Dependencies installed successfully"
}

# Function to create application user
create_user() {
    if ! id "$USER_NAME" &>/dev/null; then
        print_status "Creating application user: $USER_NAME"
        useradd -r -s /bin/false -d $APP_DIR $USER_NAME
        print_success "User $USER_NAME created"
    else
        print_warning "User $USER_NAME already exists"
    fi
}

# Function to setup application directory
setup_app_directory() {
    print_status "Setting up application directory..."
    
    # Create application directory
    mkdir -p $APP_DIR
    
    # Copy application files
    if [[ -d "./cyberguard" ]]; then
        cp -r ./cyberguard/* $APP_DIR/
    else
        print_error "Application files not found. Please run this script from the directory containing the cyberguard folder."
        exit 1
    fi
    
    # Set ownership
    chown -R $USER_NAME:$USER_NAME $APP_DIR
    
    # Create logs directory
    mkdir -p $APP_DIR/logs
    chown -R $USER_NAME:$USER_NAME $APP_DIR/logs
    
    print_success "Application directory setup complete"
}

# Function to setup Python virtual environment
setup_venv() {
    print_status "Setting up Python virtual environment..."
    
    # Create virtual environment
    sudo -u $USER_NAME python3 -m venv $VENV_DIR
    
    # Activate virtual environment and install dependencies
    sudo -u $USER_NAME $VENV_DIR/bin/pip install --upgrade pip
    sudo -u $USER_NAME $VENV_DIR/bin/pip install flask flask-cors requests
    
    print_success "Virtual environment setup complete"
}

# Function to create systemd service
create_service() {
    print_status "Creating systemd service..."
    
    cat > /etc/systemd/system/$SERVICE_NAME.service << EOF
[Unit]
Description=CyberGuard DDoS Monitoring Dashboard
After=network.target

[Service]
Type=simple
User=$USER_NAME
Group=$USER_NAME
WorkingDirectory=$APP_DIR
Environment=PATH=$VENV_DIR/bin
Environment=FLASK_ENV=production
ExecStart=$VENV_DIR/bin/python app.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

    # Reload systemd
    systemctl daemon-reload
    
    print_success "Systemd service created"
}

# Function to configure Nginx
configure_nginx() {
    print_status "Configuring Nginx..."
    
    # Remove default site
    rm -f /etc/nginx/sites-enabled/default
    
    # Create Nginx configuration
    cat > /etc/nginx/sites-available/$SERVICE_NAME << EOF
server {
    listen 80;
    server_name _;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/javascript
        application/xml+rss
        application/json;
    
    # Static files
    location /static {
        alias $APP_DIR/static;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Proxy to Flask application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # API endpoints
    location /api {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}
EOF

    # Enable site
    ln -sf /etc/nginx/sites-available/$SERVICE_NAME /etc/nginx/sites-enabled/
    
    # Test Nginx configuration
    nginx -t
    
    print_success "Nginx configuration complete"
}

# Function to configure firewall
configure_firewall() {
    print_status "Configuring firewall..."
    
    # Reset UFW to default settings
    ufw --force reset
    
    # Default policies
    ufw default deny incoming
    ufw default allow outgoing
    
    # Allow SSH
    ufw allow ssh
    
    # Allow HTTP and HTTPS
    ufw allow 80/tcp
    ufw allow 443/tcp
    
    # Allow Flask development port (optional)
    # ufw allow 5000/tcp
    
    # Enable firewall
    ufw --force enable
    
    print_success "Firewall configured"
}

# Function to configure fail2ban
configure_fail2ban() {
    print_status "Configuring fail2ban..."
    
    cat > /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime = 1h
findtime = 10m
maxretry = 5

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3

[nginx-http-auth]
enabled = true
filter = nginx-http-auth
port = http,https
logpath = /var/log/nginx/error.log
maxretry = 3

[nginx-limit-req]
enabled = true
filter = nginx-limit-req
port = http,https
logpath = /var/log/nginx/error.log
maxretry = 3
EOF

    systemctl enable fail2ban
    systemctl restart fail2ban
    
    print_success "Fail2ban configured"
}

# Function to create configuration file
create_config() {
    print_status "Creating configuration file..."
    
    cat > $APP_DIR/config.py << EOF
#!/usr/bin/env python3
"""
CyberGuard Configuration File
"""

import os

class Config:
    # Flask Configuration
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'cyberguard-secret-key-change-this-in-production'
    
    # Application Configuration
    DEBUG = False
    TESTING = False
    
    # Real Data Sources Configuration
    REAL_DATA_SOURCES = {
        'enable_real_data': False,  # Set to True to enable real data integration
        'sources': {
            'netflow': {
                'enabled': False,
                'collector_ip': '0.0.0.0',
                'port': 9995,
                'bind_ip': '0.0.0.0'
            },
            'syslog': {
                'enabled': False,
                'port': 514,
                'bind_ip': '0.0.0.0'
            },
            'api_polling': {
                'enabled': False,
                'endpoints': [
                    'http://localhost:8080/api/network/stats',
                    'http://localhost:8080/api/security/alerts'
                ],
                'interval': 30
            }
        }
    }
    
    # Logging Configuration
    LOG_LEVEL = 'INFO'
    LOG_FILE = '/opt/cyberguard/logs/cyberguard.log'
    LOG_MAX_SIZE = '10MB'
    LOG_BACKUP_COUNT = 5
    
    # Security Configuration
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # API Configuration
    API_RATE_LIMIT = '1000 per hour'
    
    # Database Configuration (for future use)
    DATABASE_URL = os.environ.get('DATABASE_URL') or 'sqlite:///cyberguard.db'

class DevelopmentConfig(Config):
    DEBUG = True
    SESSION_COOKIE_SECURE = False

class ProductionConfig(Config):
    DEBUG = False
    TESTING = False
    
    # Production-specific settings
    PREFERRED_URL_SCHEME = 'https'

config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': ProductionConfig
}
EOF

    chown $USER_NAME:$USER_NAME $APP_DIR/config.py
    print_success "Configuration file created"
}

# Function to create log rotation
create_logrotate() {
    print_status "Setting up log rotation..."
    
    cat > /etc/logrotate.d/cyberguard << EOF
$APP_DIR/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 $USER_NAME $USER_NAME
    postrotate
        systemctl reload cyberguard
    endscript
}
EOF

    print_success "Log rotation configured"
}

# Function to start services
start_services() {
    print_status "Starting services..."
    
    # Start Flask application
    systemctl enable $SERVICE_NAME
    systemctl start $SERVICE_NAME
    
    # Start Nginx
    systemctl enable nginx
    systemctl start nginx
    
    print_success "Services started"
}

# Function to display installation summary
show_summary() {
    print_success "CyberGuard DDoS Monitoring Dashboard installed successfully!"
    echo
    echo "=== Installation Summary ==="
    echo "Application Directory: $APP_DIR"
    echo "Service Name: $SERVICE_NAME"
    echo "User: $USER_NAME"
    echo "Virtual Environment: $VENV_DIR"
    echo
    echo "=== Access Information ==="
    echo "Web Interface: http://$(hostname -I | awk '{print $1}')"
    echo "API Endpoints: http://$(hostname -I | awk '{print $1}')/api"
    echo
    echo "=== Service Management ==="
    echo "Start Service: sudo systemctl start $SERVICE_NAME"
    echo "Stop Service: sudo systemctl stop $SERVICE_NAME"
    echo "Restart Service: sudo systemctl restart $SERVICE_NAME"
    echo "Check Status: sudo systemctl status $SERVICE_NAME"
    echo
    echo "=== Log Files ==="
    echo "Application Logs: $APP_DIR/logs/"
    echo "System Logs: journalctl -u $SERVICE_NAME -f"
    echo "Nginx Logs: /var/log/nginx/"
    echo
    echo "=== Configuration ==="
    echo "Main Config: $APP_DIR/config.py"
    echo "Service Config: /etc/systemd/system/$SERVICE_NAME.service"
    echo "Nginx Config: /etc/nginx/sites-available/$SERVICE_NAME"
    echo
    echo "=== Security ==="
    echo "Firewall: UFW (configured)"
    echo "Fail2ban: Active"
    echo "SSL: Not configured (recommended for production)"
    echo
    print_warning "Please configure SSL certificates for production use"
    print_warning "Change the default SECRET_KEY in $APP_DIR/config.py"
}

# Main installation function
main() {
    print_status "Starting CyberGuard DDoS Monitoring Dashboard installation..."
    
    # Pre-installation checks
    check_root
    check_ubuntu
    
    # Installation steps
    update_system
    install_dependencies
    create_user
    setup_app_directory
    setup_venv
    create_config
    create_service
    configure_nginx
    configure_firewall
    configure_fail2ban
    create_logrotate
    start_services
    
    # Show summary
    show_summary
    
    print_success "Installation complete!"
}

# Run main function
main "$@"